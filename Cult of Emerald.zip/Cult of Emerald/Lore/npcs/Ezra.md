## Overview
Ezra is an elf with a significant history involving [[Lore/locations/garondio/Garondio|Garondio]]. 

## History
Ezra formerly led the city of [[Lore/locations/garondio/Garondio|Garondio]] as a tyrant. During their rule, their unwillingness to cooperate with the metallic dragon living in Garondio's walls led to the dragon being driven away from the city. 

## Related
- [[Lore/locations/garondio/Garondio|Garondio]] - City with Ezra's history

---

Tags: #npc #lore #elf #tyrant #session-0
