## Overview
Araxa is an ancient green dragon attacking [[Lore/locations/garondio/Garondio|Garondio]]. The dragon is served by the [[dragon cult]] who collect sacrifices for Araxa. Citizens are being gathered as sacrifices to this deity.

## Session Appearances

### Session 1
During Session 1, there was a deafening roar and an ancient green dragon appeared flying over the city. The dragon flew over the keep, destroying the walls. Breathed poison breath into the keep, silencing the people inside. 

### Session 2
Name of Araxa confirmed through interrogation of captured cult member. Confirmed as the deity/leader being worshipped by the [[dragon cult]]. 


## Related
- [[Lore/locations/garondio/Garondio|Garondio]] - City being attacked
- [[dragon cult]] - Faction serving Araxa
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Quest to stop the cult

---

Tags: #npc #lore #dragon #enemy #ancient-dragon #session-1 #session-2
