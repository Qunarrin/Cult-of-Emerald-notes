## Description
A medical facility at the Black Hand barracks providing care for civilians and soldiers in [[Lore/locations/garondio/Garondio|Garondio]].

## NPCs
- [[Clerics (barracks healers tent)]] - Stationed here, devoted to god of protection

## Session Appearances

### #session-2 
[[Old Man Kraven]] visited this location to meet with the clerics.

## Related
- [[Lore/locations/Barracks|Barracks]] - Part of barracks complex #ai-edited #eddit
- [[Clerics (barracks healers tent)]] - Staff
- [[Lore/locations/garondio/Garondio|Garondio]] - Location 

---

Tags: #session-2 #location #medical
