## Overview
Garondio is a major city spanning approximately 100 miles from end to end at its longest point. The city is governed by a council where each representative is elected. 

## History
Garondio once had a metallic dragon living within its walls, but the dragon was driven away by [[Ezra|Ezra's]] unwillingness to end his tyrannical rule. 

## Districts

### Knights Market
Knights Market is a district that serves as the headquarters of [[the black hand|The Black Hand]] faction. The district features a keep that is home to nobility, guild heads, and their families.
## Government
The city is led by a council system where representatives are elected by the populace. 

## Related
- [[Ezra]] - Former tyrant leader
- [[the black hand]] - Faction with headquarters in Knights Market

---

Tags: #location #city #session-0
