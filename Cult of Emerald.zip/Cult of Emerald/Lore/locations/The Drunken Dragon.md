## Overview
The building is at least 100 years old. 

## Significance
This tavern served as the meeting point for the adventuring party, with [[Eraliea]] sending individual notes to each party member directing them to this location. 

## Related
- [[Eraliea]] - NPC who sent the party here

---

Tags: #location #tavern #session-0 #session-1
