# Barracks

## Description
A military headquarters operated by [[the black hand|The Black Hand]] mercenary group in [[Lore/locations/garondio/Garondio|Garondio]]. The barracks serves as a safe haven for citizens during the [[dragon cult]] invasion and houses military personnel defending the city.

## Location
Located approximately 1 mile from [[The Drunken Dragon]] tavern.

## Facilities
- [[Healers Tent]] - Medical facility staffed by clerics
- Command center - Where [[Barracks Commander]] directs operations
- Citizen shelter - Safe area for refugees from cult attacks

## NPCs
- [[Barracks Commander]] - Military leader stationed here
- [[Clerics (barracks healers tent)]] - Medical staff devoted to god of protection

## Session Appearances

### Session 1
Party directed citizens here for safety during [[Araxa]]'s attack. [[Eraliea]] led the party to this location as a base of operations.

### Session 2
Party returned to the barracks after combat. Met with [[Barracks Commander]]. [[Old Man Kraven]] visited the [[Healers Tent]]. Interrogated captured cultist [[Talor Scalefist]] here.

## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Serves as party's base of operations

## Related
- [[the black hand]] - Operates this facility
- [[Lore/locations/garondio/Garondio|Garondio]] - City location
- [[The Drunken Dragon]] - 1 mile away
- [[Healers Tent]] - Part of barracks complex
- [[Barracks Commander]] - Commands this facility
- [[Clerics (barracks healers tent)]] - Staff the healers tent

---

Tags: #location #barracks #military #black-hand #session-1 #session-2 
