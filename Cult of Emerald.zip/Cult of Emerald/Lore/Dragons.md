## Divine Status
Dragons are considered gods in this world. 

## Age Hierarchy
There can only be one ancient dragon at a time for each dragon subtype. Dragons partially own the lands they live on.

## Gem Dragons
Gem dragons are known for having powers that exceed the bounds of normal dragon abilities by a significant margin. They live in the Underdark as a means of escaping what they perceive as lesser races. 

## Notable Dragons
- [[Bahamut]] - The Platinum Dragon, King of Good Dragons
- [[Araxa]] - Ancient green dragon attacking Garondio 

---

Tags: #lore #dragons #world-building #session-0 #session-1
