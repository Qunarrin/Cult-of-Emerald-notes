## Overview
Bahamut is the Platinum Dragon, a Lawful Good deity and the King of Good Dragons. He appears as either a massive silver-white dragon or a wise old man. 

## Domain
Bahamut is a benevolent force against evil, especially opposing his sister Tiamat. He is the patron of Dragonborn and good metallic dragons. His domain includes justice, protection, and wisdom.  

## Manifestation
Often seen with seven songbirds accompanying him. When manifesting divine power, he utilizes radiant or cold damage.

## Related

- [[Keven]] - Cleric devoted to Bahamut 

---

Tags: #deity #dragon #lawful-good #session-0
