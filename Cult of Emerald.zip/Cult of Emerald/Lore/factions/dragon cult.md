## Overview
The Dragon Cult is a hostile organization that serves the ancient green dragon [[Araxa]]. they refer to him as "The Ancient Green One". They are currently invading [[Lore/locations/garondio/Garondio|Garondio]] and capturing citizens as sacrifices for Araxa. 

## Activities
The cult is actively collecting citizens of Garondio to use as sacrifices to Araxa. They operate with organized forces including hobgoblins, wargs, ettins, and human cultists. 

## Leadership
The cult serves [[Araxa]], an ancient green dragon as the head of the cult.  there appears to be a hierarchy of management where lesser leaders can direct forces but all respond to Araxa.


## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Party hired to investigate the Dragon Cult 

## Related
- [[Araxa]] - The dragon the cult serves
- [[Lore/locations/garondio/Garondio|Garondio]] - City being invaded by the cult

---

Tags: #faction #enemy #dragon-cult #session-1
