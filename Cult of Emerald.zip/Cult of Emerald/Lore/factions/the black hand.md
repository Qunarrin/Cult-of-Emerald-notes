# The Black Hand

## Overview
The Black Hand is a mercenary group with extensive influence throughout [[Lore/locations/garondio/Garondio|Garondio]]. They have significant control over the city's operations. 

## Headquarters
The Black Hand's main headquarters is located in the Knights Market district of Garondio, specifically within the keep. They also operate barracks located approximately 1 mile from [[The Drunken Dragon]]. 
## Insignia
The Black Hand insignia appears on the left breast of their armor. The insignia is shaped like the back of a gauntlet hand, with "BLACK" written above and "HAND" written below. It is approximately the size and shape of a drink coaster. 

## Related
- [[Lore/locations/garondio/Garondio|Garondio]] - City where The Black Hand operates
- Knights Market - District containing their headquarters
- [[Black Hand Insignia]] - Their identifying mark 

---

Tags: #faction #mercenary #session-0 #session-1
