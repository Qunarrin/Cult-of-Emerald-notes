## Status
#active

## Overview
Quest initiated when [[Eraliea]] gathered the party at [[The Drunken Dragon]]. The party has been hired by [[the black hand]] to investigate the [[dragon cult]] that is invading [[Lore/locations/garondio/Garondio|Garondio]]. Payment is offered for every solid piece of information about the cult. Initial payment: 5 platinum per party member. #ai-edited #eddit

## Objectives
- Investigate the [[dragon cult]] - In progress, captured cultist interrogated, headquarters location identified
- Gather proof about the cult's activities - In progress, cult leadership confirmed as [[Araxa]]
- Protect citizens of [[Lore/locations/garondio/Garondio|Garondio]] from cult attacks - Barracks provides shelter #ai-edited #eddit

## Events And Occurrences

### #session-2 
- Interrogated captured cultist for cult information 
- Confirmed [[Araxa]] as cult deity/leader 
- Obtained directions to cult headquarters 
- Discovered that [[Araxa]] is able to talk and affect the minds of the cultists

## Key NPCs
- [[Eraliea]] - Quest giver, Black Hand representative
- [[Talor Scalefist]] - Captured cultist, source of cult intelligence

## Related
- [[The Drunken Dragon]] - Initial meeting location
- [[the black hand]] - Mercenary group hiring the party 
- [[dragon cult]] - Target of investigation 
- [[Araxa]] - Dragon leading the cult 
- [[Barracks Commander]] - Military leader aiding investigation
- [[Clerics (barracks healers tent)]] - Support staff at barracks

---

Tags: #quest #active #session-0 #session-1 #session-2
