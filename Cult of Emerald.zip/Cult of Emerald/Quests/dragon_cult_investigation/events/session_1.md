## Actions Taken
- New party member [[Kake Shade]] joined the group
- [[Eraliea]] revealed the quest: investigate the [[dragon cult]]
- [[Eraliea]] gave each party member 5 platinum (500 gold total per person) as initial payment
- [[Eraliea]] distributed [[Black Hand Insignia]] to all party members
- Party traveled to Black Hand barracks (approximately 1 mile from [[The Drunken Dragon]])
- During travel, [[Araxa]] (ancient green dragon) attacked [[Lore/locations/garondio/Garondio|Garondio]] 
- [[Araxa]] destroyed the keep walls and breathed poison into the keep
- Party encountered hobgoblins, warg, ettin, and dragon cultists collecting citizens for sacrifice
- Party engaged in combat to rescue citizens
- [[Eraliea]] teleported in to assist, healing party members
- Party directed citizens to the Black Hand barracks for safety 

## Discoveries
- Dragons are considered gods in this world
- [[the black hand]] is a mercenary group (not just a faction)
- [[Eraliea]] is a Paladin of Tyr with healing and teleportation abilities
- [[Eraliea]] can see in magical darkness
- [[Araxa]] is an ancient green dragon attacking Garondio
- The [[dragon cult]] is collecting citizens as sacrifices for [[Araxa]]

## Combat Encounters
- Hobgoblins with bows
- Warg (monstrosity, goblinoid creature type)
- Ettin pulling cart
- Purple-robed dragon cultist (human)
- One dragon cultist surrendered

## Party Members Present
- [[Jack Schneider]]
- [[Binah]]
- [[Keven]]
- [[Old Man Kraven]]
- [[Kake Shade]] 

## Items Received
- 5 platinum per party member
- [[Black Hand Insignia]] (one)

---

Tags: #session-1 #quest-event #combat
