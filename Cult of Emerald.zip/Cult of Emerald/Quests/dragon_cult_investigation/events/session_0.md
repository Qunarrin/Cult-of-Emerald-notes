# Quest Initiation

## Actions Taken
- [[Eraliea]] sent invitations to party members to meet at [[The Drunken Dragon]] 
- All party members gathered at The Drunken Dragon

## Discoveries
- [[Eraliea]] is the quest giver for the Dragon Cult Investigation 
- Party gathering complete at The Drunken Dragon

## Party Members Gathered
- [[Jack Schneider]]
- [[Binah]]
- [[Keven]]
- [[Old Man Kraven]]

## Notes
Quest hook and objectives to be revealed in Session 1. 

---

Tags: #session-0 #quest-event
