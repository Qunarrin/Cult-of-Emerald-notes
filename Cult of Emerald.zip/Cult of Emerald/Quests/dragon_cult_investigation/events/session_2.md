# Session 2 Progress

## Actions Taken
- Looted enemies from previous session (morning star, battle axe, 50 gold from hobgoblins)
- Entered barracks and met the barracks commander
- [[Old Man Kraven]] entered healers tent and met the [[Clerics (barracks healers tent)]] devoted to [[Bahamut]]
- Attempted to interrogate captured cultist, experienced mental barrier/voice resistance
- Visited tavern en route to next location
- Interrogated captured cultist for cult information

## Discoveries
- **Cult Leader Name:** [[Araxa]] is the name of the cult's deity/leader
- **Cult Headquarters:** Directions to main cult headquarters obtained
- **Mental Defenses:** Captured cultist has force/voice that deals mental damage when attempting mental intrusion, states "You do not have permission to peer into this mind"
- **Clerics Need Promotion:** Clerics in healers tent need promotion before they can search wounds of non-critical patients

## NPCs Encountered
- [[Barracks Commander]] - Direct military leader at barracks
- [[Clerics (barracks healers tent)]] - God of protection, stationed in healers tent
- [[Talor Scalefist]] - Purple-robed cultist from Session 1, has mental defenses

## Locations Visited
- Barracks - Military headquarters
- Healers tent - Medical facility with clerics
- Tavern - On route (destination unclear)

## Objectives Progress
- [x] Investigate the [[dragon cult]] thru interrogation - 
- [ ] Gather proof about cult's activities
- [ ] Protect citizens of [[Lore/locations/garondio/Garondio|Garondio]] - Barracks provides shelter 

## Items Looted
- Morning star (picked up by [[Old Man Kraven]])
- 50 gold combined from hobgoblins

---

Tags: #session-2 #quest-dragon-cult-investigation 