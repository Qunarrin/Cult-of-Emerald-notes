# Cult of Emerald

## Campaign Overview

Campaign focused on investigating the Dragon Cult and their attack on [[Garondio]], led by the ancient green dragon [[Araxa]]. 

## By Category

### Locations
- [[Garondio]] #location #city - Major city spanning 100 miles, governed by council
- [[The Drunken Dragon]] #location #tavern - 100+ year old tavern where party gathered
- [[Healers Tent]] #location #medical - Medical facility at barracks

### Factions
- [[the black hand]] #faction #mercenary - Mercenary group operating in Garondio 
- [[dragon cult]] #faction #enemy - Cult serving Araxa. currentlly relivent to [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]]

### Deities
- [[Bahamut]] #deity - The Platinum Dragon, King of Good Dragons

### NPCs
- [[Ezra]] #npc #lore - Former tyrant ruler of Garondio
- [[Eraliea]] #npc #quest-giver - Paladin of Tyr, Black Hand representative 
- [[Araxa]] #npc #lore #dragon - Ancient green dragon attacking Garondio  
- [[Talor Scalefist]] #npc #enemy - Purple-robed cultist who surrendered 

### Players
- [[Jack Schneider]] #player-character - Reaper, folk hero (Gavin)
- [[Binah]] #player-character - Wizard chronicler (Xavier)
- [[Keven]] #player-character - Duergar cleric of Bahamut, "Dirt Diggler" (Kainnan) 
- [[Old Man Kraven]] #player-character - Spellblade, former pirate, fiendish origin (sage)
- [[Kake Shade]] #player-character - Eladrin Oathbreaker Paladin/Hexblade Warlock 

### Items
- [[Black Hand Insignia]] #item - Identification for Black Hand associates 
- [[Morning Star]] #item #weapon - Picked up by Old Man Kraven in Session 2 

### Lore
- [[Dragons]] #lore - Dragons are gods, age hierarchy.

### Quests
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] #quest #active - Investigate Dragon Cult for The Black Hand 

### Locations (Extended)
- [[Lore/locations/Barracks|Barracks]] #location #military - Black Hand barracks, base of operations  
- [[Healers Tent]] #location #medical - Medical facility at barracks  

### NPCs (vague)
- [[Barracks Commander]] #npc #indifferent - Direct military leader at barracks 
- [[Clerics (barracks healers tent)]] #npc #indifferent - Healers tent staff, devoted to god of protection  

## By Session

### Session 0
**Lore Revealed:**
- [[Garondio]] - City introduction, Knights Market district
- [[the black hand]] - Faction headquarters revealed
- [[Ezra]] - History of tyranny
- [[Dragons]] - Dragon hierarchy and gem dragon lore
- [[Bahamut]] - Deity information

**NPCs Encountered:**
- [[Eraliea]] - Invited party to The Drunken Dragon

**Locations Visited:**
- [[The Drunken Dragon]] - Initial gathering point

**Players Introduced:**
- [[Jack Schneider]]
- [[Binah]]
- [[Keven]] #update 
- [[Old Man Kraven]]

**Quests Initiated:**
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Eraliea gathered party at The Drunken Dragon #update 

### Session 1
**Lore Revealed:**
- Dragons are gods in this world  
- [[the black hand]] is a mercenary group  
- [[Araxa]] - Ancient green dragon attacking Garondio  
- [[dragon cult]] - Collecting citizens as sacrifices  

**NPCs Encountered:**
- [[Eraliea]] - Revealed quest, gave payment and insignias, fought alongside party  

**Locations Visited:**
- [[The Drunken Dragon]] - Quest briefing location  
- Black Hand barracks - Safe haven for citizens  

**Players Introduced:**
- [[Kake Shade]] - New party member  

**Items Received:**
- 5 platinum per party member (initial payment)  
- [[Black Hand Insignia]] (one per party member)  

**Quest Progress:**
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Quest objectives revealed, first combat encounter  

### Session 2
**Lore Revealed:**
- [[Araxa]] - Confirmed as cult deity/leader through interrogation  
- [[dragon cult]] - Headquarters location obtained from captured cultist  

**NPCs Encountered:**
- [[Barracks Commander]] - Met at barracks, direct military authority  
- [[Clerics (barracks healers tent)]] - Met at healers tent, need promotion for expanded medical authority  
- [[Talor Scalefist]] - Interrogated for cult intelligence, revealed mental defenses  

**Locations Visited:**
- [[Lore/locations/Barracks|Barracks]] - Military headquarters  
- [[Healers Tent]] - Medical facility with clerics  
- Tavern - En route to next destination 

**Items Acquired:**
- [[Morning Star]] - Looted, picked up by [[Old Man Kraven]] 
- 50 gold combined from hobgoblins collected by [[Binah]]

**Quest Progress:**
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Captured cultist interrogated, cult headquarters directions obtained

---

Tags: #session-prep