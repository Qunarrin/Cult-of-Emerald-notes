
## Overview
A warg creature encountered during the [[dragon cult]] attack on [[Lore/locations/garondio/Garondio|Garondio]]. This warg worked alongside hobgoblins in collecting citizens for sacrifice. 

## Characteristics
**Creature Type:** Monstrosity, Goblinoid  
**Hit Points:** Slightly over 20  

## Combat Role
The warg worked with hobgoblins (who used bows) to guard a cart being filled with captured citizens. The cart was being pulled by an ettin. 

## Session Appearances

### Session 1
Encountered during combat when the party intervened to stop the [[dragon cult]] from collecting citizens. 

## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Enemy combatant 

## Related
- [[dragon cult]] - Faction the warg serves

---

Tags: #npc #enemy #monster #warg #session-1
