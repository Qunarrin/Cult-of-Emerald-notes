# Dragon Cultist

## Overview
A human cultist wearing purple robes who serves [[Araxa]] and the [[dragon cult]]. This cultist is notable for attempting to surrender during combat and may have valuable information. 

#session-2 we got information on the location of a bace camp of the cult.  its verry possible that we are going to have to interrogate multiple enemies here in order to gain information on the cult as a whole.  
-  he comes from a family that has served The Ancient Green one for generations.
## Characteristics
**Race:** Human  
**Attire:** Purple robes  
**Magic Use:** Cast spells, including command

## Combat Behavior
During the #session-1 combat encounter, he displayed self preservation in an attempt to live he promised information. Successfully captured by [[Eraliea]].

## Mental Defenses
The cultist has a powerful mental defense mechanism - a force/voice that deals mental damage when attempts are made to peer into their mind. When threatened with mental intrusion, the cultist projects: "You do not have permission to peer into this mind."

## Session Appearances

### Session 1
Encountered during the [[dragon cult]] attack on [[Lore/locations/garondio/Garondio|Garondio]] while collecting citizens for sacrifice. Attempted to surrender during combat. 

### Session 2
Interrogated at the barracks for information on the cult. Revealed knowledge of [[Araxa]] and directions to cult headquarters. 
## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Source of information about the cult 
- gave important information on the interactions between the cult 

## Related
- [[dragon cult]] - Faction the cultist serves
- [[Araxa]] - Dragon the cultist worships

---

Tags: #npc #enemy #dragon-cultist #surrendered #session-1
