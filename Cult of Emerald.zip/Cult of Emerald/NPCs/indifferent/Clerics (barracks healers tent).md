## Overview
A group of clerics dedicated to a deity of protection. Stationed in the healers tent at the barracks in [[Lore/locations/garondio/Garondio|Garondio]]. #ai-edited #eddit

## Details
- Devoted to god of protection
- Prefer to as to view the wounds of non-critical patients
- skilled in some magic but for small injuries would prefer to use normal medicine 

## Session Appearances

### Session 2
Met by [[Old Man Kraven]] in the healers tent. 

## Related
- [[Lore/locations/garondio/Garondio|Garondio]] - Location #ai-edited #eddit
- [[Lore/locations/Barracks|Barracks]] - Work location #ai-edited #eddit
- [[Healers Tent]] - Stationed location

---

Tags: #session-2 #npc #indifferent #clerics #healers 
