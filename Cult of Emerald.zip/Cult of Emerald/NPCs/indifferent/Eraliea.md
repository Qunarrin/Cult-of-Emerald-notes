## Overview
Eraliea is a woman who works for [[the black hand|The Black Hand]] mercenary group. She wears armor with a red hand insignia on the left breast and a helmet with runes that read "May you forever serve the black camp." She is important to the [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] and serves as the quest giver. She is a Paladin of Tyr with healing abilities and can teleport. She can see in magical darkness. 

## Session Appearances

### #session-0 
Eraliea gave all players separately a note telling them to go to a tavern named The Drunken Dragon. 

### #Session-1
Eraliea placed a large bag of money on the table at The Drunken Dragon. She gave each party member 5 platinum (100 gold per piece). She hired the party to investigate the dragon cult and promised payment for every solid piece of information. She gave the party Black Hand insignias. She led the party to a Black Hand barracks approximately 1 mile from the tavern. During the dragon attack, she teleported in to assist the party in combat, proclaiming "Fear not for a paladin of Tyr has come to save thee!" She cast an aura spell that healed both Kake and Old Man Kraven, then directed the party to bring citizens to the barracks. 

## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Quest giver, central to quest initiation 

## Related
- [[The Drunken Dragon]] - Tavern where party was summoned
- [[the black hand]] - Mercenary group she works for 
- [[Black Hand Insignia]] - Item she gave to the party 

---

Tags: #npc #indifferent #quest-giver #paladin #session-0 #session-1
