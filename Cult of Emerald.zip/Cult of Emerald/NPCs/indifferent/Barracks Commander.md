## Overview
A direct military leader stationed at the barracks in [[Lore/locations/garondio/Garondio|Garondio]]. Commands forces defending against the [[dragon cult]] invasion. #ai-edited #eddit

## Personality
- Direct in how he delegates and speaks
- has an air of military bearing and authority

## Session Appearances

### Session 2
Met by the party at the barracks.

## Related
- [[Lore/locations/garondio/Garondio|Garondio]] - Location #ai-edited #eddit
- [[Lore/locations/Barracks|Barracks]] - Stationed location #ai-edited #eddit
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Quest context

---

Tags: #session-2 #npc #indifferent #military
