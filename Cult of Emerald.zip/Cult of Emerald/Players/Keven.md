**Class:** Cleric  
**Deity:** [[Bahamut]]  
**Race:** Duergar  
**Player:** Kainnan
**Title:** dirt diggler

## Background
Dirt Diggler is a cleric devoted to Bahamut. He is known throughout [[Lore/locations/garondio/Garondio|Garondio]] for his hole. #ai-edited #eddit

## Notable Quote
"If you visit Garondio and don't visit Keven's Hole, have you really been to Garondio?" 

## Related
- [[Bahamut]] - Deity worshipped
- [[Lore/locations/garondio/Garondio|Garondio]] - Location of his hole #ai-edited #eddit

---

Tags: #player-character #cleric #duergar #session-0
