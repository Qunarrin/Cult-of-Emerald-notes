## Character Overview
**Class:** Paladin (Oathbreaker), multiclassed Hexblade Warlock  
**Race:** Eladrin (type of elf)  
**Height:** 6'2"  

## Personality
Kake is ready to kill, rob, or steal if it benefits him. He carries a sense of death about him. 

## Related

---

Tags: #player-character #paladin #warlock #oathbreaker #hexblade #session-1
