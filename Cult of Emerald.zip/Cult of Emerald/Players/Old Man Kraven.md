## Character Overview
**Age:** 200 years old  
**Appearance:** Very old and wrinkly, wears a leather jacket. Has horns that hint at a fiendish origin. 
**Profession:** Ship engineer, spellblade for hire  
**Background:** Pirate / criminal 

## Personality Traits
- Memory problems
- Parties frequently
- Slightly alcoholic 
- Kleptomania
- Avoids starting crimes that would put him on the run
- Approximately 70% salt (personality trait) 

## Skills
- Ship engineering
- Infiltration 
- Navigation 
- Killing people 

## Related

---

Tags: #player-character #spellblade #pirate #session-0 #session-1
