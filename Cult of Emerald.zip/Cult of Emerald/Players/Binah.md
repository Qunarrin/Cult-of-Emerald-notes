**Class:** Wizard  
**Profession:** Historian  
**title:** the Chronicler 
**Player:** Xavier

## Background
Binah works as a historian living in a room attached to the cities historical records library. He is almost compulsive in his logging of history, driven by an insatiable need to gain knowledge. 

## Personality
- Compulsive historian
- Knowledge-driven
- Meticulous record-keeper

## Related

---

Tags: #player-character #wizard #historian #session-0
