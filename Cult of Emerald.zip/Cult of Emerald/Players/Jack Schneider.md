# Jack Schneider (Gavin)

## Character Overview
**Class:** Reaper  
**Race:** Scarecrow  
**Player:** Gavin

## Background
Jack Schneider stopped a goblin incursion and became a folk hero to the people. As for the goblins, he is viewed as a monster by the goblins due to his actions.

## Reputation
- **Among people:** Folk hero
- **Among goblins:** Monster

## Related

---

Tags: #player-character #reaper #folk-hero #session-0
