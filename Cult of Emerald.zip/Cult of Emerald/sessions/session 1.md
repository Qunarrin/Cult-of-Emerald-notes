
# start
- portents 4 18 Binah temp ability 
## slight lore while explaining to new player   
- dragons are gods.  #lore 
- the black hand is a mercenary group #lore 
### new player name kake shade
	is 6 foot 2 in 
	is ready to kill rob or steal if it benifits him
	is paladen othbreaker muticlassed hexblade warlock 
	race eladrin (type of elf)
	carrys a mouring star 
## session notes continuing 
	the drunken dragon is atllest an 100 year old buling
	old mand kraven appers to be verry old and wrinkly wears a leather jaket.  has horns that hint on a findish origin 
	old man kraven is slightlly alcoholic
	carrys a since of death (kake)
	drink, fire ball, tastes of the essence of fire.  
	woman, read hand insignia, leaft breast on the armor.  runes on helmit (may you forever serve the black camp)  
### dragon cult
	dragons are invading 
	normally investigators would be hired but the cerumstances caused the party to be hired by her
## continuing 
	woman placed a large bag of money that is to large to hold by the bottem
	gives everyone 5 platnum (100 gold per piece)
	woman gives us info se wants information on the dragon cult for every solid peice of information 
	gives us an insignia of the black hand.  it is a back side of a gaunntleted hand with black written above it and hand written below. the full thing is about the size and shape of a drink coster.  
	the woman leades us to a black hand barracks aprox 1 minle away from the tavern
	there a deffingin roar (dragon?)
	after looking up we see an anchent green dragon.
	by the time we make it to the barricks the dragon flew over the keep destroying the walls of the keep.  perception check (soljers jumping form the walls in fear.  the dragon breaths poison breath in to the keep silincing the people in the keep)
	erailea (the woman)  walking in to the barricks sitting at a desk instructs us to colleckts the citizens and bring them in to the barricks 
### collection sequence 
	old man (the player) climbs a building 
#### cart that's being filled with people 
	theres hobgoblins collecting people in a kart thats drawn by an etten (see monsters in universall library).   
	both kake and old turn invisable to close in 
	araxa is an entity (probabbly the green dragon) they are collecting the people as sacrifices.  
##### combat 
	old man attacks the etten using a spell to fling a bit of fire that singes the rope
	hobgoblin attacks old man with bow launcing 2 arrows missing 1 arrow and a second arrow as the old man cast a spell to make it miss.  
	pourple man cast a spell shouting "grovle before the might of araxa"
	old man is possably 70% salt
	warg has ara of athority form the leader. no restanceancy or immunitys. hitpoints is slightlly over 20.  is creature type monstrosity, goblinoid.  
	erailea telopoerts in se announsed "fear not for a paladin of tier has come to save thie!" then casts a aura spell that heals the others both kake and the old man
	erailea sees in magical darkness?
	dragon cultist is trying to surrender.  
	erailea heals kake for alot 
	erailea instructs the players to direct the players bring the citizens to the barricks
	erailea drags the cultest that surenderd by his hood
	combat end 
	
	
	
	
	
	
	
###### condition refrence 
## Blinded

- A blinded creature can't see and automatically fails any ability check that requires sight.
- Attack rolls against the creature have advantage, and the creature's attack rolls have disadvantage.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Charmed)Charmed

- A charmed creature can't attack the charmer or target the charmer with harmful abilities or magical effects.
- The charmer has advantage on any ability check to interact socially with the creature.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Deafened)Deafened

- A deafened creature can't hear and automatically fails any ability check that requires hearing.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Exhaustion)Exhaustion

Some special abilities and environmental hazards, such as starvation and the long-term effects of freezing or scorching temperatures, can lead to a special condition called exhaustion. Exhaustion is measured in six levels. An effect can give a creature one or more levels of exhaustion, as specified in the effect's description.

|Level|Effect|
|---|---|
|1|Disadvantage on ability checks|
|2|Speed halved|
|3|Disadvantage on attack rolls and saving throws|
|4|Hit point maximum halved|
|5|Speed reduced to 0|
|6|Death|

  
If an already exhausted creature suffers another effect that causes exhaustion, its current level of exhaustion increases by the amount specified in the effect's description.

A creature suffers the effect of its current level of exhaustion as well as all lower levels. For example, a creature suffering level 2 exhaustion has its speed halved and has disadvantage on ability checks.

An effect that removes exhaustion reduces its level as specified in the effect's description, with all exhaustion effects ending if a creature's exhaustion level is reduced below 1.  
Finishing a long rest reduces a creature's exhaustion level by 1, provided that the creature has also ingested some food and drink. Also, being raised from the dead reduces a creature’s exhaustion level by 1.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Frightened)Frightened

- A frightened creature has disadvantage on ability checks and attack rolls while the source of its fear is within line of sight.
- The creature can't willingly move closer to the source of its fear.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Grappled)Grappled

- A grappled creature's speed becomes 0, and it can't benefit from any bonus to its speed.
- The condition ends if the grappler is [incapacitated](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#IncapacitatedCondition) (see the condition).
- The condition also ends if an effect removes the grappled creature from the reach of the grappler or grappling effect, such as when a creature is hurled away by the [thunderwave](https://www.dndbeyond.com/spells/2278-thunderwave) spell.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Incapacitated)Incapacitated

- An incapacitated creature can't take actions or reactions.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Invisible)Invisible

- An invisible creature is impossible to see without the aid of magic or a special sense. For the purpose of hiding, the creature is heavily obscured. The creature's location can be detected by any noise it makes or any tracks it leaves.
- Attack rolls against the creature have disadvantage, and the creature's attack rolls have advantage.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Paralyzed)Paralyzed

- A paralyzed creature is [incapacitated](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#IncapacitatedCondition) (see the condition) and can't move or speak.
- The creature automatically fails Strength and Dexterity saving throws. Attack rolls against the creature have advantage.
- Any attack that hits the creature is a critical hit if the attacker is within 5 feet of the creature.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Petrified)Petrified

- A petrified creature is transformed, along with any nonmagical object it is wearing or carrying, into a solid inanimate substance (usually stone). Its weight increases by a factor of ten, and it ceases aging.
- The creature is [incapacitated](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#IncapacitatedCondition) (see the condition), can't move or speak, and is unaware of its surroundings.
- Attack rolls against the creature have advantage.
- The creature automatically fails Strength and Dexterity saving throws.
- The creature has resistance to all damage.
- The creature is immune to poison and disease, although a poison or disease already in its system is suspended, not neutralized.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Poisoned)Poisoned

- A poisoned creature has disadvantage on attack rolls and ability checks.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Prone)Prone

- A prone creature's only movement option is to crawl, unless it stands up and thereby ends the condition.
- The creature has disadvantage on attack rolls.
- An attack roll against the creature has advantage if the attacker is within 5 feet of the creature. Otherwise, the attack roll has disadvantage.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Restrained)Restrained

- A restrained creature's speed becomes 0, and it can't benefit from any bonus to its speed.
- Attack rolls against the creature have advantage, and the creature's attack rolls have disadvantage.
- The creature has disadvantage on Dexterity saving throws.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Stunned)Stunned

- A stunned creature is [incapacitated](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#IncapacitatedCondition) (see the condition), can't move, and can speak only falteringly.
- The creature automatically fails Strength and Dexterity saving throws.
- Attack rolls against the creature have advantage.

## [](https://www.dndbeyond.com/sources/dnd/basic-rules-2014/appendix-a-conditions?srsltid=AfmBOorD63O2u4wh7A2kGuHgHAv4UDcg1PB1fREtpCsAba-Ngd-EKb3M#Unconscious)Unconscious

- An unconscious creature is [incapacitated](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#IncapacitatedCondition), can't move or speak, and is unaware of its surroundings.
- The creature drops whatever it's holding and falls [prone](https://www.dndbeyond.com/sources/dnd/free-rules/rules-glossary#ProneCondition).
- The creature automatically fails Strength and Dexterity saving throws.
- Attack rolls against the creature have advantage.
- Any attack that hits the creature is a critical hit if the attacker is within 5 feet of the creature.



