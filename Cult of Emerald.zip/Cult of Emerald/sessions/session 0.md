



# lore 

## garondio 
![[Pasted image 20251211024456.png]]
has a faction that is named the black hand they have a hold of mostly any
 **knights market** (district) is the main head quarters of the black hand   is the keep. is the home to nobility as well.  the head of the guilds and all nobilities families live here.
  this city once had a metallic dragon living in its walls but it was driven away by the ezras unwillingness ness to c.  
  **ezra** ia an elf that lead the citty as a tyrant 
  is lead by a council that leads the town each rep is elected as part of 
  form the longest part form end to end is about 100 miles
 

## dragons
age hierarchy 
	there can only be one ancient dragon at a time  for each sub type.   
	dragons exist in 
	dragons sort of half own the lands they live on 
	 gem dragons are known for have power that exceed the bounds of normal dragons powers by alot
	 ***Bahamut*** is the Platinum Dragon, a [Lawful Good deity](https://www.google.com/search?client=opera&q=Lawful+Good+deity&sourceid=opera&ie=UTF-8&oe=UTF-8&mstk=AUtExfCej1SL0Abpkg9uoEike6QhgGlsLWC559yIXotRmTDLOtto1LPdcbrhKJNL7mXJZi-pMNMGNnGhoSvYd8C6L6HpdZ4BhtRMTk2HbTCIfcwiXTPnyzFLkhDpZUXJ5AOHIx6TJjZEokaSjzswR8UEJwy1noQ2M9g7D8lGVSgZra2_MjEENLa-YoJeHR7VaiY1s1q9V0wA4qBFM8EifRR2c9HU9xaj9QrN3v5ltCkK9qW7WB38c57Wsnqke8F3q1S0YpOe6GJJDALNfq_62mQFzo4k&csui=3&ved=2ahUKEwjIyqvpvLSRAxW82wIHHXmdIkIQgK4QegQIARAC) and the King of Good Dragons, appearing as a massive silver-white dragon or a wise old man, a benevolent force against evil, especially his sister Tiamat, often seen with seven songbirds, representing justice, protection, and wisdom, and is a patron of [Dragonborn](https://www.google.com/search?client=opera&q=Dragonborn&sourceid=opera&ie=UTF-8&oe=UTF-8&mstk=AUtExfCej1SL0Abpkg9uoEike6QhgGlsLWC559yIXotRmTDLOtto1LPdcbrhKJNL7mXJZi-pMNMGNnGhoSvYd8C6L6HpdZ4BhtRMTk2HbTCIfcwiXTPnyzFLkhDpZUXJ5AOHIx6TJjZEokaSjzswR8UEJwy1noQ2M9g7D8lGVSgZra2_MjEENLa-YoJeHR7VaiY1s1q9V0wA4qBFM8EifRR2c9HU9xaj9QrN3v5ltCkK9qW7WB38c57Wsnqke8F3q1S0YpOe6GJJDALNfq_62mQFzo4k&csui=3&ved=2ahUKEwjIyqvpvLSRAxW82wIHHXmdIkIQgK4QegQIARAD) and good metallic dragons, often utilizing radiant or cold damage in his divine manifestations
	 gem dragons live in the under dark as a mode of escaping what they see as lesser races. 
	 

## players

**jack Schneider** player name *gavin* playing a the class **reaper**   race "scarecrow guy"     stoped a goblin incursion be became a folk hero to the people and a monster to the goblins

**Binah** player name *xavier* the chronicler  **wizard**  he works in order to gain knowledge as a **historian** living in a room attached to the library.  is almost compulsive in his logging of history. 

**keven**      player name **kainnan** dirt diggler    is a **cleric** to Bahamut.  **race** duergar   "if you visit gurando and don't visit kainnans hole have you really been to gurando" 

**old man kraven** old man      has lived for 200 years has memory problems, parties a lot, kleptomania, pirate. is a ship engenier, is old and does not like to start crime that puts him on the run.  is good at getting to places and killing people, is a spellblade for hire. 


## players gathering 
eraliea hands all players sepratlly a note that tells them to go to a tavern named the drunken dragon.  



# campaign title 
cult of emerald


session 0