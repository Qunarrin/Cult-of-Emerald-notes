## session start
#### loot from the enemys from last session 
mouning star picked up  by old man
battle axe  leaft

both hobgoblens had 50 gold combined   

### session event 
meet the barracks commander he is quite direct in how he directs.  

old enters the healers tent and meets the clerics (god of protection) 

the cultist that we captuered has a force / voice that delt some mental damage as i tryed to probe the mind  after saying " you do not have permition to pear in to this mind"

we enter a tavern on the way to the 


##### info form the cult
i learn the name of araxa 
directions to the main headquarters of the cult 


##### details on clerics
they need promotion to search the wounds of non critical.


