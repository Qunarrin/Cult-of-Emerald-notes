## Description
A melee weapon (morning star/mace variant). Picked up as loot from defeated enemies in [[session 2]].

## Current Status
Held by [[Old Man Kraven]]

## Session Appearances

### Session 2
Found as loot from defeated hobgoblins. Picked up by [[Old Man Kraven]].

## Related
- [[Old Man Kraven]] - Current holder
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Quest context

---

Tags: #session-2 #item #weapon 
