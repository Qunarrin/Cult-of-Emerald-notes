## Description
The Black Hand insignia is shaped like the back of a gauntleted hand, with "black" written above and "hand" written below. It is approximately the size and shape of a drink coaster. 

## Purpose
The insignia identifies members or associates of [[the black hand]] mercenary group. It was given to the party by [[Eraliea]] to show they are working for The Black Hand while investigating the [[dragon cult]]. 

## Quest Relevance
- [[Quests/dragon_cult_investigation/dragon_cult_investigation_overview|Dragon Cult Investigation]] - Given to party as identification while working for The Black Hand 

## Related
- [[the black hand]] - The mercenary group the insignia represents
- [[Eraliea]] - NPC who gave the insignia

---

Tags: #item #insignia #identification #session-1
